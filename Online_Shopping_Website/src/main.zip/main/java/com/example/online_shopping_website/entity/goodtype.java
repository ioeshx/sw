package com.example.online_shopping_website.entity;

public class goodtype {
}
