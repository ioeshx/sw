package com.example.online_shopping_website.entity.constant;

public class TransactionType {
    public static final int charge = 0;

}
