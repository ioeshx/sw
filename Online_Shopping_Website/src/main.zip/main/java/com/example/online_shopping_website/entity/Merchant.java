package com.example.online_shopping_website.entity;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.io.Serializable;

@Data
public class Merchant extends User implements Serializable {
    private float account;
}
