package com.example.online_shopping_website.entity.constant;

public class UserType {
    public static final int admin = 0;

    public static final int merchant = 1;

    public static final int buyer = 2;
}
