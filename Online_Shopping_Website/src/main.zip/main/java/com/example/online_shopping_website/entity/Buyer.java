package com.example.online_shopping_website.entity;

import java.io.Serializable;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
public class Buyer extends User implements Serializable {

}
